import numpy as np, pickle, sys
from scipy.stats import norm, spearmanr
from sklearn.linear_model import RidgeCV
import simulation_core as sim

def simulate_het(n, avec, rng, rho_c=0.9, nu=1.0, d=4):
    S=0.7*np.eye(d)+0.3
    z=rng.multivariate_normal(np.zeros(d),S,n)
    g=rng.standard_normal((n,d)); s=avec[None,:]*np.exp(0.6*g-0.36)
    def panel():
        c=z+s*rng.standard_normal((n,d))
        gr=rho_c*g+np.sqrt(1-rho_c**2)*rng.standard_normal((n,d))
        w=2*nu*avec[None,:]*np.exp(0.6*gr-0.36)
        return c,w
    return z,panel(),panel()

def zs(c): return (c-c.mean(0))/c.std(0)
def pct(c): return norm.cdf(zs(c))            # normalise to (0,1), higher = better governance

def composites(c, wts_rel=None):
    P=pct(c); Z=zs(c)
    out={}
    out['arith']=-Z.mean(1)                                   # risk = -quality
    out['geom']=-np.exp(np.log(np.clip(P,1e-3,1)).mean(1))
    out['min']=-P.min(1)
    if wts_rel is not None: out['rel_w']=-(Z*wts_rel).sum(1)/wts_rel.sum()
    return out

def run(seed, avec, n=600, nt=1000):
    rng=np.random.default_rng(seed)
    z,(cA,wA),(cB,wB)=simulate_het(n,avec,rng)
    y=sim.f(z)+np.sqrt(0.1/0.9)*rng.standard_normal(n)
    r=np.array([np.corrcoef(cA[:,j],cB[:,j])[0,1] for j in range(4)])   # reliability from two providers
    snr=np.clip(r,0.02,0.98)/(1-np.clip(r,0.02,0.98))
    zt,(tA,twA),(tB,twB)=simulate_het(nt,avec,rng); ft=sim.f(zt)
    # supervised
    mu,sd=cA.mean(0),cA.std(0)
    lin=RidgeCV(alphas=np.logspace(-3,2,12)).fit((cA-mu)/sd,y)
    Z=sim.design((cA-mu)/sd,wA/sd,'gauss',True)
    fz=RidgeCV(alphas=np.logspace(-3,2,12),fit_intercept=False).fit(Z,y)
    def allscores(c,w):
        sc=composites(c,snr); sc['reg_lin']=lin.predict((c-mu)/sd)
        sc['fuzzy_rules']=sim.design((c-mu)/sd,w/sd,'gauss',True)@fz.coef_
        return sc
    SA,SB=allscores(tA,twA),allscores(tB,twB)
    crit=(zt<=-1.5).any(1)       # a critical failure on at least one indicator
    top=ft>=np.quantile(ft,0.8)
    res={}
    for k in SA:
        a,b=SA[k],SB[k]
        qa=a>=np.quantile(a,.8); qb=b>=np.quantile(b,.8)
        safe=a<=np.quantile(a,.5)       # ranked in safest half
        res[k]=(spearmanr(a,ft)[0], spearmanr(a,b)[0], (qa&qb).sum()/qa.sum(), (qa&top).sum()/qa.sum(), (safe&crit).sum()/crit.sum())
    res['snr']=snr; res['r']=r
    return res

SCEN={'homog':np.array([0.9,0.9,0.9,0.9]),
      'reliable_on_key':np.array([0.5,0.5,1.4,1.4]),      # z1,z2 carry most weight in f
      'unreliable_on_key':np.array([1.4,1.4,0.5,0.5])}
if __name__=='__main__':
    R=int(sys.argv[1]); out={}
    for nm,av in SCEN.items():
        out[nm]=[run(2000+k,av) for k in range(R)]; print(nm,flush=True)
    pickle.dump(out,open('composite.pkl','wb'))
