import numpy as np, itertools, json, sys
from scipy.stats import norm, spearmanr, rankdata
from sklearn.linear_model import RidgeCV
rng_master = np.random.SeedSequence(20261111)

sig = lambda x: 1/(1+np.exp(-x))
def f_raw(z):
    return 1.4*sig(-2*(z[:,0]+z[:,1])) + sig(-3*z[:,2])*(0.5+0.5*sig(-2*z[:,3])) - 0.25*z[:,0]*z[:,3]
ref = np.random.default_rng(1).multivariate_normal(np.zeros(4), 0.7*np.eye(4)+0.3, 20000)
F_SD = f_raw(ref).std(); F_MU = f_raw(ref).mean()
f = lambda z: (f_raw(z)-F_MU)/F_SD

def simulate(n, a, rho_c, nu, rng, d=4):
    S = 0.7*np.eye(d)+0.3
    z = rng.multivariate_normal(np.zeros(d), S, n)
    g = rng.standard_normal((n,d))
    s = a*np.exp(0.6*g-0.36)
    def panel():
        c = z + s*rng.standard_normal((n,d))
        grep = rho_c*g + np.sqrt(1-rho_c**2)*rng.standard_normal((n,d))
        w = 2*nu*a*np.exp(0.6*grep-0.36)
        return c, w
    cA,wA = panel(); cB,wB = panel()
    return z, (cA,wA), (cB,wB)

# triangular(c-w,c,c+w) mass in [lo,hi]
def tri_cdf(x, c, w):
    t = (x-c)/w
    return np.where(t<=-1,0.0,np.where(t<=0,0.5*(1+t)**2,np.where(t<1,1-0.5*(1-t)**2,1.0)))
TG = np.linspace(-1,1,41); TW = (1-np.abs(TG)); TW = TW/TW.sum()

CENT = np.array([-1.,0.,1.]); WID=0.7; CUT=np.array([-0.5,0.5])
def term_matrix(c, w, term, fuzzy):
    """returns (n,d,K) truth degrees of the K terms of every indicator"""
    n,d = c.shape
    out = np.zeros((n,d,3))
    if term=='bool':
        lo = np.array([-np.inf,-0.5,0.5]); hi=np.array([-0.5,0.5,np.inf])
        for k in range(3):
            if fuzzy:
                out[:,:,k] = tri_cdf(hi[k],c,w)-tri_cdf(lo[k],c,w)
            else:
                out[:,:,k] = ((c>lo[k])&(c<=hi[k])).astype(float)
    else:
        for k in range(3):
            if fuzzy:
                x = c[:,:,None] + w[:,:,None]*TG[None,None,:]
                out[:,:,k] = (np.exp(-(x-CENT[k])**2/(2*WID**2))*TW).sum(-1)
            else:
                out[:,:,k] = np.exp(-(c-CENT[k])**2/(2*WID**2))
    return out

def design(c, w, term, fuzzy):
    T = term_matrix(c,w,term,fuzzy)
    n,d,K = T.shape
    combos = list(itertools.product(range(K),repeat=d))
    tau = np.ones((n,len(combos)))
    for r,cb in enumerate(combos):
        for j,k in enumerate(cb): tau[:,r]*=T[:,j,k]
    phi = tau/np.maximum(tau.sum(1,keepdims=True),1e-12)
    X1 = np.hstack([np.ones((n,1)),c])
    Z = (phi[:,:,None]*X1[:,None,:]).reshape(n,-1)
    return Z

def one_rep(a, rho_c, nu, seed, n=600, ntest=1000):
    rng = np.random.default_rng(seed)
    z,(cA,wA),(cB,wB) = simulate(n,a,rho_c,nu,rng)
    var = 0.1/0.9
    y = f(z)+np.sqrt(var)*rng.standard_normal(n)
    zt,(tA,twA),(tB,twB) = simulate(ntest,a,rho_c,nu,rng)
    ft = f(zt)
    mu,sd = cA.mean(0),cA.std(0)
    nz = lambda c,w:((c-mu)/sd, w/sd)
    cA,wA = nz(cA,wA); tA,twA = nz(tA,twA); tB,twB = nz(tB,twB)
    res={}
    for term in ('bool','gauss'):
        for fuzzy in (False,True):
            Z = design(cA,wA,term,fuzzy)
            m = RidgeCV(alphas=np.logspace(-3,2,12), fit_intercept=False).fit(Z,y)
            pA = design(tA,twA,term,fuzzy)@m.coef_
            pB = design(tB,twB,term,fuzzy)@m.coef_
            rmse = np.sqrt(np.mean((pA-ft)**2))
            sp = spearmanr(pA,pB)[0]
            qa = pA>=np.quantile(pA,0.8); qb = pB>=np.quantile(pB,0.8)
            ov = (qa&qb).sum()/qa.sum()
            # Boolean decision: flag top 20% -> agreement with true top 20%
            qt = ft>=np.quantile(ft,0.8)
            hit = (qa&qt).sum()/qa.sum()
            res[f'{term}_{"fuzzy" if fuzzy else "crisp"}']=(rmse,sp,ov,hit)
    return res

if __name__=='__main__':
    R=40
    settings=[(0.25,0.9,1.0),(0.5,0.9,1.0),(0.9,0.9,1.0),(1.4,0.9,1.0),(0.9,0.0,1.0)]
    out={}
    for (a,rc,nu) in settings:
        agg={}
        for r in range(R):
            res = one_rep(a,rc,nu,seed=1000*r+int(a*10)+int(rc*7))
            for k,v in res.items(): agg.setdefault(k,[]).append(v)
        out[f'a={a},rho_c={rc}']={k:np.array(v) for k,v in agg.items()}
        print(a,rc,flush=True)
    import pickle; pickle.dump(out,open('res.pkl','wb'))
